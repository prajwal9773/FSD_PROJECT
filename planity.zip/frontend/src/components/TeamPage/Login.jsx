import React from "react";
import Background from "./Background.jsx";
const Login = () => {
  return (
    <div>
      <Background />
    </div>
  );
};
export default Login;
